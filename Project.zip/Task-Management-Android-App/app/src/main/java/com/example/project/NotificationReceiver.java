package com.example.project;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.example.project.ui.newTask.NewTaskFragment;

public class NotificationReceiver extends BroadcastReceiver {
    private static final String MY_CHANNEL_ID = "my_chanel_1";

    @Override
    public void onReceive(Context context, Intent intent) {
        NewTaskFragment nf = new NewTaskFragment();
        nf.createNotificationChannel(context); // Ensure channel is created

        nf.createNotification(context, "title", "body");
    }

}